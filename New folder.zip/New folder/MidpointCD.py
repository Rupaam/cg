x0, y0 = map(int, input().split())
r = int(input())

x = 0
y = r

p = 1 - r

oct1 = [(x, y)]

while x <= y:

    if p < 0:
        x += 1
        p = p + 2*x + 1
        oct1.append((x, y))

    else:
        x += 1
        y -= 1
        p = p + 2*x - 2*y + 1
        oct1.append((x, y))


oct2 = []
circle = []

oct1.reverse()

f = 1

for pt in oct1:
    if f:
        f = 0
        continue

    oct2.append((pt[1], pt[0]))


oct1.reverse()

for pt in oct2:
    oct1.append((pt[0], pt[1]))


# Q1
for pt in oct1:
    circle.append((pt[0], pt[1]))

# Q2
for pt in oct1:
    circle.append((-pt[0], pt[1]))

# Q3
for pt in oct1:
    circle.append((-pt[0], -pt[1]))

# Q4
for pt in oct1:
    circle.append((pt[0], -pt[1]))


print("Circle points:")

for pt in circle:
    print(f"({pt[0]}, {pt[1]})", end=" , ")