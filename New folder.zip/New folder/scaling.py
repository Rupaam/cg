import numpy as np
import matplotlib.pyplot as plt

p=np.array([[2,2],[5,2],[4,4],[2,2]])
sx=2
sy=3
S=np.array([[sx,0],
 [0,sy]])
q=p@S.T

plt.plot(p[:,0],p[:,1],marker='o',label='Original')
plt.plot(q[:,0],q[:,1],marker='o',label='Scaled')
plt.legend()
plt.grid()
plt.axis('equal')
plt.show()