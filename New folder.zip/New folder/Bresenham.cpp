#include<bits/stdc++.h>
using namespace std;
#define F first
#define S second
typedef long long ll;
int main(){
ll i,j;
double
x0,y0,xn,yn;
cin>>x0>>y0;
cin>>xn>>yn;
vector< pair<ll,ll> >
line; ll delX,delY;
delX = abs(xn-x0);
delY = abs(yn-y0);
double m = 2*delY -
delX; ll step = delX-1;
double x = x0;
double y = y0;
line.push_back( { x, y }
); for(i=1; i<=step+10;
i++)
{
if(i==1)
{
x = x0;

y = y0;
}
if(m<0)
{
m = (m + (2*delY));
line.push_back( { x, y } );
}
else
{
m =(m + (2*delY) - (2*delX));
x++;
y++;
line.push_back( { x, y } );
}
if( (x==xn) &&
(y==yn) ) break;
}
cout<<"line points: "<<endl;
for(auto p : line)
{
cout<<p.F<<" , "<<p.S<<endl;
}
}