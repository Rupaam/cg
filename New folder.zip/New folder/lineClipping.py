import matplotlib.pyplot as plt

xmin, ymin = 20, 20
xmax, ymax = 80, 60
x1, y1 = 10, 10
x2, y2 = 90, 70
m = (y2 - y1) / (x2 - x1)
xl = xmin
yl = y1 + m * (xl - x1)
yt = ymax
xt = x1 + (yt - y1) / m
plt.plot([xmin,xmax,xmax,xmin,xmin],
 [ymin,ymin,ymax,ymax,ymin],
 'b-', label="Clipping Window")
plt.plot([x1,x2], [y1,y2],
 '--', color='orange', label="Original Line")
plt.plot([xl,xt], [yl,yt],
 'g-', linewidth=3, label="Clipped Line")

plt.xlabel("X")
plt.ylabel("Y")
plt.title("Cohen-Sutherland Line Clipping")
plt.legend()
plt.grid()

plt.xlim(0,100)
plt.ylim(0,80)

plt.show()