import numpy as np
import matplotlib.pyplot as plt
p=np.array([[2,2],[5,2],[4,4],[2,2]])

tx=3
ty=4
T=np.array([[1,0,tx],
 [0,1,ty],
 [0,0,1]])

h=np.column_stack((p,np.ones(len(p))))
q=h@T.T

plt.plot(p[:,0],p[:,1],marker='o',label='Original')
plt.plot(q[:,0],q[:,1],marker='o',label='Translated')
plt.legend()
plt.grid()
plt.axis('equal')
plt.show()