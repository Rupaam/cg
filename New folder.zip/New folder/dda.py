x0, y0 = map(float, input().split())
xn, yn = map(float, input().split())

line = []

delX = abs(xn - x0)
delY = abs(yn - y0)

m = delY / delX
step = max(delX, delY)

x = x0
y = y0

for i in range(1, int(step) + 1):

    if m < 1:
        x = x + 1
        y = y + m
        line.append((round(x), round(y)))

    elif m > 1:
        x = x + (1 / m)
        y = y + 1
        line.append((round(x), round(y)))

    else:
        x = x + 1
        y = y + 1
        line.append((round(x), round(y)))

print("Line points:")

for p in line:
    print(p[0], ",", p[1])