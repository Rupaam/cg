import math

x0, y0 = map(float, input().split())
xn, yn = map(float, input().split())
line = []
delX = abs(xn - x0)
delY = abs(yn - y0)

m = 2 * delY - delX
step = delX - 1
x = x0
y = y0
line.append((x, y))
for i in range(1, int(step) + 11):
    if i == 1:
        x = x0
        y = y0
    if m < 0:
        m = m + 2 * delY
        line.append((x, y))
    else:
        m = m + 2 * delY - 2 * delX
        x += 1
        y += 1
        line.append((x, y))
    if x == xn and y == yn:
        break
print("line points:")
for p in line:
    print(p[0], ",", p[1])