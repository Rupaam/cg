x0, y0 = map(int, input().split())
r = int(input())

x = 0
y = r
p = 3 - 2 * r

circle = []

while x <= y:

    # 8 symmetric points
    circle.append((x0+x, y0+y))
    circle.append((x0+y, y0+x))
    circle.append((x0-y, y0+x))
    circle.append((x0-x, y0+y))

    circle.append((x0-x, y0-y))
    circle.append((x0-y, y0-x))
    circle.append((x0+y, y0-x))
    circle.append((x0+x, y0-y))

    if p < 0:
        x += 1
        p = p + 4*x + 6
    else:
        x += 1
        y -= 1
        p = p + 4*(x-y) + 10

print("Circle points:")

for point in circle:
    print(point)