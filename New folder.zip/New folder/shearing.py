import numpy as np
import matplotlib.pyplot as plt

p=np.array([[2,2],[5,2],[4,4],[2,2]])

shx=1
shy=0
S=np.array([[1,shx],
 [shy,1]])
q=p@S.T

plt.plot(p[:,0],p[:,1],marker='o',label='Original')
plt.plot(q[:,0],q[:,1],marker='o',label='Sheared')
plt.legend()
plt.grid()
plt.axis('equal')
plt.show()