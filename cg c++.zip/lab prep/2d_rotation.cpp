#include<graphics.h>
#include<iostream>
#include<cmath>
#include<conio.h>
using namespace std;
int main(){
    int gd = DETECT,gm;
    float x1,y1,x2,y2;
    float an, rad;
    initgraph(&gd,&gm,"");
    cout<<"Enter 1st(x1,y2):";
    cin>>x1>>y1;
    cout<<"Enter 2nd (x2,y2):";
    cin>>x2>>y2;
    cout<<"Enter angle: ";
    cin>>an;
    setcolor(WHITE);
    line(x1,y1,x2,y2);
    rad = an*3.14159/180;
    float x1new = x1*cos(rad)-y1*sin(rad);
    float y1new = x1*sin(rad)+y1*cos(rad);
    float x2new = x2*cos(rad)-y2*sin(rad);
    float y2new = x2*sin(rad)+y2*cos(rad);
    setcolor(RED);
    setlinestyle(SOLID_FILL,0,THICK_WIDTH);
    line(round(x1new),round(y1new),round(x2new),round(y2new));
    getch();
    closegraph();
    return 0;
}

