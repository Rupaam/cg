#include<graphics.h>
#include<iostream>
using namespace std;
int xmin = 100,ymin = 100;
int xmax = 400,ymax = 300;
int getCode(int x,int y){
    int code = 0;
    if(y>ymax)
        code |=8;
    if(y<ymin)
        code|=4;
    if(x>xmax)
        code|=2;
    if(x<xmin)
        code |=1;
    return code;
}
void clipLine(int x1,int y1,int x2,int y2){
    int code1 = getCode(x1,y1);
    int code2 = getCode(x2,y2);
    bool accept = false;
    while(true){
        if((code1 | code2)==0){
            accept=true;
            break;
        }else if(code1&code2)
            break;
        else{
            int codeOut;
            if(code1!=0)
                codeOut = code1;
            else
                codeOut = code2;
            float x,y;
            if(codeOut&8){
                x=x1+(x2-x1)*(ymax-y1)/(float)(y2-y1);
                y=ymax;
            }else if(codeOut&4){
                x = x1+(x2-x1)*(ymin-y1)/(float)(y2-y1);
                y=ymin;
            }else if(codeOut&2){
                y=y1+(y2-y1)*(xmax-x1)/(float)(x2-x1);
                x=xmax;
            }else{
                y=y1+(y2-y1)*(xmin-x1)/(float)(x2-x1);
                x=xmin;
            }
            if(codeOut==code1){
                x1=(int)x;
                y1=(int)y;
                code1=getCode(x1,y1);
            }else{
                x2=(int)x;
                y2=(int)y;
                code2=getCode(x2,y2);
            }
        }
    }
    if(accept){
        setcolor(RED);
        line(x1,y1,x2,y2);
    }
}
int main(){
    int gd = DETECT,gm;
    initgraph(&gd,&gm,"");
    int x1=50,y1=50,x2=450,y2=350;
    setcolor(WHITE);
    rectangle(xmin,ymin,xmax,ymax);
    setcolor(YELLOW);
    line(x1,y1,x2,y2);
    clipLine(x1,y1,x2,y2);
    getch();
    closegraph();
}

