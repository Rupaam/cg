#include<graphics.h>
#include<iostream>
#include<conio.h>
#include<cmath>
#include<vector>
using namespace std;
void dda(){
     int gd = DETECT,gm;
    int x1,y1,x2,y2;
    float x,y;
    float dx,dy,m;
    initgraph(&gd,&gm,"");
    cout<<"enter x1,y1: ";
    cin>>x1>>y1;
    cout<<"enter x2,y2: ";
    cin>>x2>>y2;
    dx = x2-x1;
    dy = y2-y1;
    m = dy/dx;
    x = x1,
    y=y1;
    putpixel(round(x),round(y),WHITE);
    if(m<1){
        while(x<x2){
            x=x+1;
            y=y+m;
            putpixel(round(x),round(y),WHITE);
        }
    }else if(m==1){
        while(x<x2){
            x=x+1;
            y=y+1;
            putpixel(round(x),round(y),WHITE);
        }
    }else{
        while(y<y2){
            x=x+(1/m);
            y=y+1;
            putpixel(round(x),round(y),WHITE);
        }
    }
    getch();
    closegraph();
}
void bresenshamline(){
    int gd = DETECT,gm;
    int x0,y0,xn,yn;
    int dx,dy;
    int pk;

    initgraph(&gd,&gm,"");
    cout<<"Enter x0 y0: ";
    cin>>x0>>y0;
    cout<<"Enter xn yn: ";
    cin>>xn>>yn;

    dx = xn-x0;
    dy = yn-y0;

    pk = 2*dy-dx;
    while(x0<=xn){
        putpixel(x0,y0,YELLOW);
        x0++;
        if(pk<0){
            pk=pk+2*dy;
        }else{
            y0++;
            pk=pk+2*dy-2*dx;
        }
    }
    getch();
    closegraph();
}
void midpointCircle(int xk,int yk,int r){
    int x=0;
    int y=r;
    int pk=1-r;
    while(x<=y){
        putpixel(xk + x, yk + y, CYAN);
        putpixel(xk - x, yk + y, CYAN);
        putpixel(xk + x, yk - y, CYAN);
        putpixel(xk - x, yk - y, CYAN);

        putpixel(xk + y, yk + x, CYAN);
        putpixel(xk - y, yk + x, CYAN);
        putpixel(xk + y, yk - x, CYAN);
        putpixel(xk - y, yk - x, CYAN);
        x++;
        if(pk<0){
            pk=pk+2*x+1;
        }else{
            y--;
            pk=pk+2*x-2*y+1;
        }
    }
}
void bresenhamCircle(int x0,int y0,int r){
    int x=0;
    int y=r;
    int pk=3-2*r;
    while(x<=y){
        putpixel(x0 + x, y0 + y, GREEN);
        putpixel(x0 - x, y0 + y, GREEN);
        putpixel(x0 + x, y0 - y, GREEN);
        putpixel(x0 - x, y0 - y, GREEN);

        putpixel(x0 + y, y0 + x, GREEN);
        putpixel(x0 - y, y0 + x, GREEN);
        putpixel(x0 + y, y0 - x, GREEN);
        putpixel(x0 - y, y0 - x, GREEN);
        x++;
        if(pk<0){
            pk=pk+4*x+6;
        }else{
            y--;
            pk=pk+4*(x-y)+10;
        }
    }
}
void translation_2d(){
    int gd = DETECT, gm;
    int x1,y1;
    int s;
    int tx,ty;
    initgraph(&gd,&gm,"");
    cout<<"Enter (x,y)";
    cin>>x1>>y1;
    cout<<"Enter s:";
    cin>>s;
    cout<<"Enter (tx,ty)";
    cin>>tx>>ty;

    int x2 = x1+s;
    int y2 = y1;
    int x3 = x1+s;
    int y3 = y1 +s;
    int x4 = x1;
    int y4 =y1+s;
    setcolor(WHITE);
    line(x1,y1,x2,y2);
    line(x2,y2,x3,y3);
    line(x3,y4,x4,y4);
    line(x4,y4,x1,y1);
    x1 = x1+tx;
    y1 = y1+ty;
    x2 = x2+tx;
    y2 = y2+ty;
    x3 = x3+tx;
    y3 = y3+ty;
    x4 = x4+tx;
    y4 = y4+ty;
    setcolor(RED);
    line(x1,y1,x2,y2);
    line(x2,y2,x3,y3);
    line(x3,y3,x4,y4);
    line(x4,y4,x1,y1);
    getch();
    closegraph();
}
void reflection_2d(){
     int gd = DETECT,gm;
    float x1,y1,x2,y2,x3,y3;
    int ax = 250;
    initgraph(&gd,&gm,"");
    cout<<"Enter (x1,y1): ";
    cin>>x1>>y1;
    cout<<"Enter (x2,y2): ";
    cin>>x2>>y2;
    cout<<"Enter (x3,y3): ";
    cin>>x3>>y3;
    setcolor(WHITE);
    line(x1,y1,x2,y2);
    line(x2,y2,x3,y3);
    line(x3,y3,x1,y1);
    int y1new=2*ax-y1;
    int y2new=2*ax-y2;
    int y3new=2*ax-y3;
    setcolor(CYAN);
    setlinestyle(SOLID_FILL,0,THICK_WIDTH);
    line(x1,y1new,x2,y2new);
    line(x2,y2new,x3,y3new);
    line(x3,y3new,x1,y1new);
    setcolor(RED);
    line(0,ax,getmaxx(),ax);
    getch();
    closegraph();
}
void rotation_2d(){
    int gd = DETECT,gm;
    float x1,y1,x2,y2;
    float an, rad;
    initgraph(&gd,&gm,"");
    cout<<"Enter 1st(x1,y2):";
    cin>>x1>>y1;
    cout<<"Enter 2nd (x2,y2):";
    cin>>x2>>y2;
    cout<<"Enter angle: ";
    cin>>an;
    setcolor(WHITE);
    line(x1,y1,x2,y2);
    rad = an*3.14159/180;
    float x1new = x1*cos(rad)-y1*sin(rad);
    float y1new = x1*sin(rad)+y1*cos(rad);
    float x2new = x2*cos(rad)-y2*sin(rad);
    float y2new = x2*sin(rad)+y2*cos(rad);
    setcolor(RED);
    setlinestyle(SOLID_FILL,0,THICK_WIDTH);
    line(round(x1new),round(y1new),round(x2new),round(y2new));
    getch();
    closegraph();
}
void shearing_2d(){
    int gd = DETECT,gm;
    initgraph(&gd,&gm,"");
    int x1,y1,x2,y2,x3,y3;
    cout<<"Enter (x1,y1): ";
    cin>>x1>>y1;
    cout<<"Enter (x2,y2): ";
    cin>>x2>>y2;
    cout<<"Enter (x3,y3): ";
    cin>>x3>>y3;
    float shx,shy;
    cout<<"Enter shearing (shx,shy)";
    cin>>shx>>shy;
    setcolor(WHITE);
    line(x1,y1,x2,y2);
    line(x2,y2,x3,y3);
    line(x3,y3,x1,y1);
    int x1new=x1+shx*y1;
    int y1new=y1+shy*x1;
    int x2new=x2+shx*y2;
    int y2new=y2+shy*x2;
    int x3new=x3+shx*y3;
    int y3new=y3+shy*x3;
    setcolor(CYAN);
    setlinestyle(SOLID_FILL,0,THICK_WIDTH);
    line(x1new,y1new,x2new,y2new);
    line(x2new,y2new,x3new,y3new);
    line(x3new,y3new,x1new,y1new);
    getch();
    closegraph();
}
//  line clipping
int xmin = 100,ymin = 100;
int xmax = 400,ymax = 300;
int getCode(int x,int y){
    int code = 0;
    if(y>ymax)
        code |=8;
    if(y<ymin)
        code|=4;
    if(x>xmax)
        code|=2;
    if(x<xmin)
        code |=1;
    return code;
}
void clipLine(int x1,int y1,int x2,int y2){
    int code1 = getCode(x1,y1);
    int code2 = getCode(x2,y2);
    bool accept = false;
    while(true){
        if((code1 | code2)==0){
            accept=true;
            break;
        }else if(code1&code2)
            break;
        else{
            int codeOut;
            if(code1!=0)
                codeOut = code1;
            else
                codeOut = code2;
            float x,y;
            if(codeOut&8){
                x=x1+(x2-x1)*(ymax-y1)/(float)(y2-y1);
                y=ymax;
            }else if(codeOut&4){
                x = x1+(x2-x1)*(ymin-y1)/(float)(y2-y1);
                y=ymin;
            }else if(codeOut&2){
                y=y1+(y2-y1)*(xmax-x1)/(float)(x2-x1);
                x=xmax;
            }else{
                y=y1+(y2-y1)*(xmin-x1)/(float)(x2-x1);
                x=xmin;
            }
            if(codeOut==code1){
                x1=(int)x;
                y1=(int)y;
                code1=getCode(x1,y1);
            }else{
                x2=(int)x;
                y2=(int)y;
                code2=getCode(x2,y2);
            }
        }
    }
    if(accept){
        setcolor(RED);
        line(x1,y1,x2,y2);
    }
}

// Polygon clipping
int xmi = 100,ymi=100,xma=400,yma=300;
struct Point{
    float x,y;
};
bool isIn(Point p, int edge){
    switch(edge){
    case 0: return p.x>=xmi;
    case 1: return p.x<=xma;
    case 2: return p.y>=ymi;
    case 3: return p.y<=yma;
    }
    return false;
}
Point intersect(Point p1,Point p2,int edge){
    Point ip;
    float x1=p1.x,y1=p1.y,x2=p2.x,y2=p2.y;
    switch(edge){
    case 0:
        ip.x=xmi;
        ip.y=y1+(y2-y1)*(xmi-x1)/(x2-x1);
        break;
    case 1:
        ip.x=xma;
        ip.y=y1+(y2-y1)*(xma-x1)/(x2-x1);
        break;
    case 2:
        ip.y=ymi;
        ip.x=x1+(x2-x1)*(ymi-y1)/(y2-y1);
        break;
    case 3:
        ip.y=yma;
        ip.x=x1+(x2-x1)*(yma-y1)/(y2-y1);
        break;
    }
    return ip;
}
vector<Point> cAE(vector<Point> &inPoly,int edge){
    vector<Point> outPoly;
    int n=inPoly.size();
    if(n==0) return outPoly;
    for(int i=0;i<n;i++){
        Point current = inPoly[i];
        Point prev = inPoly[(i-1+n)%n];
        bool currentInside=isIn(current,edge);
        bool prevInside=isIn(prev,edge);
        if(currentInside){
            if(!prevInside){
                outPoly.push_back(intersect(prev,current,edge));
            }
            outPoly.push_back(current);
        }else if(prevInside){
            outPoly.push_back(intersect(prev,current,edge));
        }
    }
    return outPoly;
}
vector<Point> slh(vector<Point> polygon){
    vector<Point> result=polygon;
    for(int edge=0;edge<4;edge++){
        result=cAE(result,edge);
        if(result.empty()) break;
    }
    return result;
}
void drawPolygon(vector<Point> &poly,int color){
    if(poly.size()<2) return;
    setcolor(color);
    int n=poly.size();
    for(int i=0;i<n;i++){
        Point p1=poly[i];
        Point p2=poly[(i+1)%n];
        line((int)p1.x,(int)p1.y,(int)p2.x,(int)p2.y);
    }
}

int main(){
   // dda algo input
    // dda();

   // bresenham line
//    bresenshamline();

   // midpoint circle
     int gd = DETECT, gm;
     int xk,yk,r;
     initgraph(&gd,&gm,"");
     cout<<"Enter xk yk: ";
     cin>>xk>>yk;
     cout<<"Enter r: ";
     cin>>r;
     midpointCircle(xk,yk,r);
     getch();
     closegraph();

   // bresenham circle
    // int gd = DETECT,gm;
    // int x0,y0,r;

    // initgraph(&gd,&gm,"");
    // cout<<"Enter x0 y0: ";
    // cin>>x0>>y0;
    // cout<<"Enter r: ";
    // cin>>r;
    // bresenhamCircle(x0,y0,r);
    // getch();
    // closegraph();


   // 2d_translation
//   translation_2d();

//    reflection_2d();
//    rotation_2d();
//    shearing_2d();

   // line clipping
    // int gd = DETECT,gm;
    // initgraph(&gd,&gm,"");
    // int x1=50,y1=50,x2=450,y2=350;
    // setcolor(WHITE);
    // rectangle(xmin,ymin,xmax,ymax);
    // setcolor(YELLOW);
    // line(x1,y1,x2,y2);
    // clipLine(x1,y1,x2,y2);
    // getch();
    // closegraph();


    // polygon Clipping

//    int gd=DETECT,gm;
//    initgraph(&gd,&gm,"");
//    setcolor(WHITE);
//    rectangle(xmi,ymi,xma,yma);
//    vector<Point> subject={
//        {50,150},
//        {250,50},
//        {450,150},
//        {350,350}
//        // ,{150,300}
//    };
//    drawPolygon(subject,YELLOW);
//    vector<Point> clipped=slh(subject);
//    drawPolygon(clipped,RED);
//    getch();
//    closegraph();


}
