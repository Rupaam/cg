#include<graphics.h>
#include<iostream>
#include<vector>
using namespace std;
int xmin = 100,ymin=100,xmax=400,ymax=300;
struct Point{
    float x,y;
};
bool isIn(Point p, int edge){
    switch(edge){
    case 0: return p.x>=xmin;
    case 1: return p.x<=xmax;
    case 2: return p.y>=ymin;
    case 3: return p.y<=ymax;
    }
    return false;
}
Point intersect(Point p1,Point p2,int edge){
    Point ip;
    float x1=p1.x,y1=p1.y,x2=p2.x,y2=p2.y;
    switch(edge){
    case 0:
        ip.x=xmin;
        ip.y=y1+(y2-y1)*(xmin-x1)/(x2-x1);
        break;
    case 1:
        ip.x=xmax;
        ip.y=y1+(y2-y1)*(xmax-x1)/(x2-x1);
        break;
    case 2:
        ip.y=ymin;
        ip.x=x1+(x2-x1)*(ymin-y1)/(y2-y1);
        break;
    case 3:
        ip.y=ymax;
        ip.x=x1+(x2-x1)*(ymax-y1)/(y2-y1);
        break;
    }
    return ip;
}
vector<Point> cAE(vector<Point> &inPoly,int edge){
    vector<Point> outPoly;
    int n=inPoly.size();
    if(n==0) return outPoly;
    for(int i=0;i<n;i++){
        Point current = inPoly[i];
        Point prev = inPoly[(i-1+n)%n];
        bool currentInside=isIn(current,edge);
        bool prevInside=isIn(prev,edge);
        if(currentInside){
            if(!prevInside){
                outPoly.push_back(intersect(prev,current,edge));
            }
            outPoly.push_back(current);
        }else if(prevInside){
            outPoly.push_back(intersect(prev,current,edge));
        }
    }
    return outPoly;
}
vector<Point> slh(vector<Point> polygon){
    vector<Point> result=polygon;
    for(int edge=0;edge<4;edge++){
        result=cAE(result,edge);
        if(result.empty()) break;
    }
    return result;
}
void drawPolygon(vector<Point> &poly,int color){
    if(poly.size()<2) return;
    setcolor(color);
    int n=poly.size();
    for(int i=0;i<n;i++){
        Point p1=poly[i];
        Point p2=poly[(i+1)%n];
        line((int)p1.x,(int)p1.y,(int)p2.x,(int)p2.y);
    }
}
int main(){
    int gd=DETECT,gm;
    initgraph(&gd,&gm,"");
    setcolor(WHITE);
    rectangle(xmin,ymin,xmax,ymax);
    vector<Point> subject={
        {50,150},
        {250,50},
        {450,150},
        {350,350},
        {150,300}
    };
    drawPolygon(subject,YELLOW);
    vector<Point> clipped=slh(subject);
    drawPolygon(clipped,RED);
    getch();
    closegraph();

}

