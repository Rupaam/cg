#include<graphics.h>
#include<iostream>

#include<conio.h>
using namespace std;

int main(){
    int gd = DETECT,gm;
    int x0,y0,xn,yn;
    int dx,dy;
    int pk;

    initgraph(&gd,&gm,"");
    cout<<"Enter x0 y0: ";
    cin>>x0>>y0;
    cout<<"Enter xn yn: ";
    cin>>xn>>yn;

    dx = xn-x0;
    dy = yn-y0;

    pk = 2*dy-dx;
    while(x0<=xn){
        putpixel(x0,y0,YELLOW);
        x0++;
        if(pk<0){
            pk = pk + 2*dy;
        }
        else{
            y0++;
            pk = pk+2*dy-2*dx;
        }
    }
    getch();
    closegraph();

}



