#include<graphics.h>
#include<iostream>
#include<cmath>
using namespace std;

int main(){
    int gd = DETECT, gm;
    int x1, y1, x2, y2;

    float x, y;
    float dx, dy, M;

    initgraph(&gd, &gm, "");

    cout << "Enter x1 y1: ";
    cin >> x1 >> y1;

    cout << "Enter x2 y2: ";
    cin >> x2 >> y2;

    dx = x2 - x1;
    dy = y2 - y1;

    M = dy/dx;
    x = x1;
    y = y1;
    putpixel(round(x),round(y),WHITE);

    if(M<1){
        while(x<x2){
            x=x+1;
            y = y+M;
            putpixel(round(x),round(y),WHITE);
        }
    }else if(M==1){
        while(x<x2){
            x = x+1;
            y = y+1;
            putpixel(round(x),round(y),WHITE);
        }
    }else{
        while(y<y2){
            x = x+(1/M);
            y = y+1;
            putpixel(round(x),round(y),WHITE);
        }
    }

    getch();
    closegraph();
}

