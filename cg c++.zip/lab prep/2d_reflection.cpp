#include<graphics.h>
#include<iostream>
#include<conio.h>
using namespace std;
int main(){
    int gd = DETECT,gm;
    float x1,y1,x2,y2,x3,y3;
    int ax = 250;
    initgraph(&gd,&gm,"");
    cout<<"Enter (x1,y1): ";
    cin>>x1>>y1;
    cout<<"Enter (x2,y2): ";
    cin>>x2>>y2;
    cout<<"Enter (x3,y3): ";
    cin>>x3>>y3;
    setcolor(WHITE);
    line(x1,y1,x2,y2);
    line(x2,y2,x3,y3);
    line(x3,y3,x1,y1);
    int y1new=2*ax-y1;
    int y2new=2*ax-y2;
    int y3new=2*ax-y3;
    setcolor(CYAN);
    setlinestyle(SOLID_FILL,0,THICK_WIDTH);
    line(x1,y1new,x2,y2new);
    line(x2,y2new,x3,y3new);
    line(x3,y3new,x1,y1new);
    setcolor(RED);
    line(0,ax,getmaxx(),ax);
    getch();
    closegraph();

}

