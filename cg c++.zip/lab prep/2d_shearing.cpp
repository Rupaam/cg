#include<graphics.h>
#include<iostream>
using namespace std;
int main(){
    int gd = DETECT,gm;
    initgraph(&gd,&gm,"");
    int x1,y1,x2,y2,x3,y3;
    cout<<"Enter (x1,y1): ";
    cin>>x1>>y1;
    cout<<"Enter (x2,y2): ";
    cin>>x2>>y2;
    cout<<"Enter (x3,y3): ";
    cin>>x3>>y3;
    float shx,shy;
    cout<<"Enter shearing (shx,shy)";
    cin>>shx>>shy;
    setcolor(WHITE);
    line(x1,y1,x2,y2);
    line(x2,y2,x3,y3);
    line(x3,y3,x1,y1);
    int x1new=x1+shx*y1;
    int y1new=y1+shy*x1;
    int x2new=x2+shx*y2;
    int y2new=y2+shy*x2;
    int x3new=x3+shx*y3;
    int y3new=y3+shy*x3;
    setcolor(CYAN);
    setlinestyle(SOLID_FILL,0,THICK_WIDTH);
    line(x1new,y1new,x2new,y2new);
    line(x2new,y2new,x3new,y3new);
    line(x3new,y3new,x1new,y1new);
    getch();
    closegraph();

}

