#include<graphics.h>
#include<iostream>
#include<conio.h>
using namespace std;
int main(){
    int gd = DETECT,gm;
    float x1,y1;
    float s;
    float sx,sy;
    initgraph(&gd,&gm,"");
    cout<<"Enter (x,y): ";
    cin>>x1>>y1;
    cout<<"Enter length: ";
    cin>>s;
    cout<<"Enter (sx,sy): ";
    cin>>sx>>sy;
    float x2new = x1+s;
    float y2new = y1;
    float x3new = x1+s;
    float y3new = y1+s;
    float x4new = x1;
    float y4new = y1+s;
    setcolor(WHITE);
    setlinestyle(SOLID_FILL,0,THICK_WIDTH);
    line(x1,y1,x2new,y2new);
    line(x2new,y2new,x3new,y3new);
    line(x3new,y3new,x4new,y4new);
    line(x4new,y4new,x1,y1);
    x1=x1*sx;
    y1=y1*sy;
    x2new=x2new*sx;
    y2new=y2new*sy;
    x3new=x3new*sx;
    y3new=y3new*sy;
    x4new=x4new*sx;
    y4new=y4new*sy;
    setcolor(CYAN);
    line(x1,y1,x2new,y2new);
    line(x2new,y2new,x3new,y3new);
    line(x3new,x3new,x4new,y4new);
    line(x4new,y4new,x1,y1);
    getch();
    closegraph();

}

