
#include<graphics.h>
#include<conio.h>
#include<iostream>
using namespace std;

int main()
{
    int gd = DETECT, gm;
    int x1,y1;
    int s;
    int tx,ty;
    initgraph(&gd,&gm,"");
    cout<<"Enter (x,y)";
    cin>>x1>>y1;
    cout<<"Enter s:";
    cin>>s;
    cout<<"Enter (tx,ty)";
    cin>>tx>>ty;

    int x2 = x1+s;
    int y2 = y1;
    int x3 = x1+s;
    int y3 = y1 +s;
    int x4 = x1;
    int y4 =y1+s;
    setcolor(WHITE);
    line(x1,y1,x2,y2);
    line(x2,y2,x3,y3);
    line(x3,y4,x4,y4);
    line(x4,y4,x1,y1);
    x1 = x1+tx;
    y1 = y1+ty;
    x2 = x2+tx;
    y2 = y2+ty;
    x3 = x3+tx;
    y3 = y3+ty;
    x4 = x4+tx;
    y4 = y4+ty;
    setcolor(RED);
    line(x1,y1,x2,y2);
    line(x2,y2,x3,y3);
    line(x3,y3,x4,y4);
    line(x4,y4,x1,y1);
    getch();
    closegraph();
    return 0;
}
