
import matplotlib.pyplot as plt
import math

n = int(input("Number of vertices: "))
x, y = [], []

for i in range(n):
    a, b = map(float, input("x y: ").split())
    x.append(a)
    y.append(b)

angle = float(input("Angle in degrees: "))
t = math.radians(angle)

nx = [a*math.cos(t) - b*math.sin(t) for a,b in zip(x,y)]
ny = [a*math.sin(t) + b*math.cos(t) for a,b in zip(x,y)]

plt.plot(x + x[:1], y + y[:1], 'b-o', label="Original")
plt.plot(nx + nx[:1], ny + ny[:1], 'r-o', label="Rotated")

plt.axis('equal')
plt.grid()
plt.legend()
plt.show()
