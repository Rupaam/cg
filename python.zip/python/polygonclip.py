
import matplotlib.pyplot as plt

xmin, ymin = map(float, input("Window min x y: ").split())
xmax, ymax = map(float, input("Window max x y: ").split())

n = int(input("Number of vertices: "))
poly = []

for i in range(n):
    x, y = map(float, input("x y: ").split())
    poly.append((x, y))

original = poly[:]

def clip(poly, edge, value):
    result = []
    if not poly:
        return result

    def inside(p):
        if edge == 0: return p[0] >= value
        if edge == 1: return p[0] <= value
        if edge == 2: return p[1] >= value
        return p[1] <= value

    for i in range(len(poly)):
        a, b = poly[i-1], poly[i]
        ia, ib = inside(a), inside(b)

        if ia != ib:
            if edge < 2:
                t = (value-a[0])/(b[0]-a[0])
            else:
                t = (value-a[1])/(b[1]-a[1])

            p = (a[0]+t*(b[0]-a[0]),
                 a[1]+t*(b[1]-a[1]))
            result.append(p)

        if ib:
            result.append(b)

    return result

for edge, value in enumerate([xmin, xmax, ymin, ymax]):
    poly = clip(poly, edge, value)

def draw(points, style, label):
    if points:
        p = points + points[:1]
        x, y = zip(*p)
        plt.plot(x, y, style, label=label)

draw(original, 'b--', "Original")
draw(poly, 'r-', "Clipped")

plt.plot([xmin,xmax,xmax,xmin,xmin],
         [ymin,ymin,ymax,ymax,ymin], 'k-', label="Window")

plt.axis('equal')
plt.grid()
plt.legend()
plt.show()
