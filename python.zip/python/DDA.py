
import matplotlib.pyplot as plt

x1, y1 = map(int, input("Start x y: ").split())
x2, y2 = map(int, input("End x y: ").split())

dx = x2 - x1
dy = y2 - y1
steps = max(abs(dx), abs(dy), 1)

xi = dx / steps
yi = dy / steps

xs, ys = [], []

for i in range(steps + 1):
    xs.append(round(x1))
    ys.append(round(y1))

    x1 += xi
    y1 += yi

# plt.plot(xs, ys, 'b-', marker='s')
plt.plot(xs,ys)
plt.axis('equal')
plt.grid()
plt.show()
