
import matplotlib.pyplot as plt

n = int(input("Number of vertices: "))
x, y = [], []

for i in range(n):
    a, b = map(float, input("x y: ").split())
    x.append(a)
    y.append(b)

choice = input("Reflect X / Y / O / XY: ").upper()

if choice == 'X':
    nx, ny = x[:], [-b for b in y]
elif choice == 'Y':
    nx, ny = [-a for a in x], y[:]
elif choice == 'O':
    nx, ny = [-a for a in x], [-b for b in y]
else:
    nx, ny = y[:], x[:]

plt.plot(x + x[:1], y + y[:1], 'b-o', label="Original")
plt.plot(nx + nx[:1], ny + ny[:1], 'r-o', label="Reflected")

plt.axhline(0, color='black', linewidth=0.5)
plt.axvline(0, color='black', linewidth=0.5)
plt.axis('equal')
plt.grid()
plt.legend()
plt.show()
