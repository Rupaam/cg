import matplotlib.pyplot as plt

x1,y1=map(int,input("Start X1 Y1: ").split())
x2,y2=map(int,input("END X2 Y2: ").split())

dx=x2-x1
dy=y2-y1
p=2*dy-dx

xs,ys=[],[]

for i in range(dx+1):
  xs.append(x1)
  ys.append(y1)
  if(p<0):
    p=p+2*dy
    x1+=1
  else:
    p=p+2*dy-2*dx
    x1+=1
    y1+=1
plt.plot(xs,ys,"-b",marker="s")
plt.axis("equal")
plt.grid()
plt.show()