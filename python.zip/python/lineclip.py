
import matplotlib.pyplot as plt

xmin, ymin = map(float, input("Window min x y: ").split())
xmax, ymax = map(float, input("Window max x y: ").split())
x1, y1 = map(float, input("Start x y: ").split())
x2, y2 = map(float, input("End x y: ").split())

ox, oy = [x1, x2], [y1, y2]

def code(x, y):
    c = 0
    if x < xmin: c |= 1
    if x > xmax: c |= 2
    if y < ymin: c |= 4
    if y > ymax: c |= 8
    return c

while True:
    c1, c2 = code(x1, y1), code(x2, y2)

    if not (c1 | c2):
        accept = True
        break
    if c1 & c2:
        accept = False
        break

    c = c1 or c2

    if c & 8:
        x = x1 + (x2-x1)*(ymax-y1)/(y2-y1)
        y = ymax
    elif c & 4:
        x = x1 + (x2-x1)*(ymin-y1)/(y2-y1)
        y = ymin
    elif c & 2:
        y = y1 + (y2-y1)*(xmax-x1)/(x2-x1)
        x = xmax
    else:
        y = y1 + (y2-y1)*(xmin-x1)/(x2-x1)
        x = xmin

    if c == c1:
        x1, y1 = x, y
    else:
        x2, y2 = x, y

plt.plot([xmin,xmax,xmax,xmin,xmin],
         [ymin,ymin,ymax,ymax,ymin], 'k-', label="Window")
plt.plot(ox, oy, 'b--', label="Original")

if accept:
    plt.plot([x1,x2], [y1,y2], 'r-', linewidth=3, label="Clipped")
else:
    print("Line rejected")

plt.axis('equal')
plt.grid()
plt.legend()
plt.show()
