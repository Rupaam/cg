
import matplotlib.pyplot as plt

n = int(input("Number of vertices: "))
x, y = [], []

for i in range(n):
    a, b = map(float, input("x y: ").split())
    x.append(a)
    y.append(b)

shx, shy = map(float, input("shx shy: ").split())

nx = [a + shx*b for a,b in zip(x,y)]
ny = [b + shy*a for a,b in zip(x,y)]

plt.plot(x + x[:1], y + y[:1], 'b-o', label="Original")
plt.plot(nx + nx[:1], ny + ny[:1], 'r-o', label="Sheared")

plt.axis('equal')
plt.grid()
plt.legend()
plt.show()
