
import matplotlib.pyplot as plt

cx, cy = map(int, input("Center x y: ").split())
r = int(input("Radius: "))

x, y = 0, r
p = 3 - 2*r

while x <= y:
    for a, b in [(x,y), (y,x), (-x,y), (-y,x),
                 (x,-y), (y,-x), (-x,-y), (-y,-x)]:
        plt.plot(cx+a, cy+b, 'bs')

    if p < 0:
        p += 4*x + 6
    else:
        p += 4*(x-y) + 10
        y -= 1
    x += 1

plt.axis('equal')
plt.grid()
plt.show()
