
import matplotlib.pyplot as plt

cx, cy = map(int, input("Center x y: ").split())
r = int(input("Radius: "))

x, y = 0, r
p = 1 - r

while x <= y:
    for a, b in [(x,y), (y,x), (-x,y), (-y,x),
                 (x,-y), (y,-x), (-x,-y), (-y,-x)]:
        plt.plot(cx+a, cy+b, 'bs', markersize=9)

    if p < 0:
        p += 2*x + 3
    else:
        p += 2*(x-y) + 5
        y -= 1
    x += 1

plt.axis('equal')
plt.grid()
plt.show()

