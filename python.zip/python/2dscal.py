
import matplotlib.pyplot as plt

n = int(input("Number of vertices: "))
x, y = [], []

for i in range(n):
    a, b = map(float, input("x y: ").split())
    x.append(a)
    y.append(b)

sx, sy = map(float, input("sx sy: ").split())

nx = [a*sx for a in x]
ny = [b*sy for b in y]

plt.plot(x + x[:1], y + y[:1], 'b-o', label="Original")
plt.plot(nx + nx[:1], ny + ny[:1], 'r-o', label="Scaled")

plt.axis('equal')
plt.grid()
plt.legend()
plt.show()
