import matplotlib.pyplot as plt
import math

cx, cy = map(int, input("Center x y: ").split())
r = int(input("Radius: "))

x, y = 0, r
p = 3 - 2*r
pts = set()

while x <= y:
    for a, b in [(x,y), (y,x), (-x,y), (-y,x),
                 (x,-y), (y,-x), (-x,-y), (-y,-x)]:
        pts.add((cx + a, cy + b))

    if p < 0:
        p += 4*x + 6
    else:
        p += 4*(x-y) + 10
        y -= 1
    x += 1

pts = sorted(pts)

print("Points on the circle:")
for p in pts:
    print(p)

plt.figure(figsize=(12, 12))
plt.scatter([p[0] for p in pts], [p[1] for p in pts], s=30, c='blue')

for px, py in pts:
    dx, dy = px - cx, py - cy
    d = max(math.hypot(dx, dy), 1)
    plt.annotate(f"({px},{py})", (px, py), textcoords="offset points",
                 xytext=(14*dx/d, 14*dy/d), fontsize=6,
                 ha='center', va='center')

plt.margins(0.15)
plt.axis('equal')
plt.grid()
plt.show()
