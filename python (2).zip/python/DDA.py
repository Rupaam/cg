import matplotlib.pyplot as plt

x1, y1 = map(int, input("Start x y: ").split())
x2, y2 = map(int, input("End x y: ").split())

dx = x2 - x1
dy = y2 - y1
steps = max(abs(dx), abs(dy), 1)

xi = dx / steps
yi = dy / steps

xs, ys = [], []

for i in range(steps + 1):
    xs.append(round(x1))
    ys.append(round(y1))

    x1 += xi
    y1 += yi

pts = list(zip(xs, ys))

print("Points that draw the line:")
for p in pts:
    print(p)

plt.plot(xs, ys, '-b', marker='s', markersize=5, label="DDA line")
plt.scatter(xs, ys, s=30, c='red', zorder=3, label="Plotted points")

for px, py in pts:
    plt.annotate(f"({px},{py})", (px, py), textcoords="offset points",
                 xytext=(0, 6), fontsize=7, rotation=90,
                 ha='center', va='bottom')

plt.margins(0.15)
plt.axis('equal')
plt.grid()
plt.legend()
plt.show()
