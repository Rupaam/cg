import matplotlib.pyplot as plt

n = int(input("Number of vertices: "))
x, y = [], []

for i in range(n):
    a, b = map(float, input("x y: ").split())
    x.append(a)
    y.append(b)

sx, sy = map(float, input("sx sy: ").split())

nx = [a*sx for a in x]
ny = [b*sy for b in y]

print("Original points:", list(zip(x, y)))
print("Scaled points:", list(zip(nx, ny)))

plt.fill(x, y, color='blue', alpha=0.15)
plt.plot(x + x[:1], y + y[:1], 'b-o', markersize=6, label="Original")

plt.fill(nx, ny, color='red', alpha=0.25)
plt.plot(nx + nx[:1], ny + ny[:1], 'r-o', markersize=6, label="Scaled")

for px, py in zip(x, y):
    plt.annotate(f"({px:g},{py:g})", (px, py), textcoords="offset points",
                 xytext=(6, 6), fontsize=8, color='blue')
for px, py in zip(nx, ny):
    plt.annotate(f"({px:g},{py:g})", (px, py), textcoords="offset points",
                 xytext=(6, -12), fontsize=8, color='red')

plt.margins(0.15)
plt.axis('equal')
plt.grid()
plt.legend()
plt.show()
