import matplotlib.pyplot as plt

x1, y1 = map(int, input("Start X1 Y1: ").split())
x2, y2 = map(int, input("END X2 Y2: ").split())

dx = x2 - x1
dy = y2 - y1
p = 2 * dy - dx

xs, ys = [], []

for i in range(dx + 1):
    xs.append(x1)
    ys.append(y1)

    if p < 0:
        p += 2 * dy
        x1 += 1
    else:
        p += 2 * dy - 2 * dx
        x1 += 1
        y1 += 1

pts = list(zip(xs, ys))

print("Points that draw the line:")
for p in pts:
    print(p)

plt.plot(xs, ys, "-b", marker="s", markersize=5, label="Bresenham line")
plt.scatter(xs, ys, s=30, c='red', zorder=3, label="Plotted points")

for px, py in pts:
    plt.annotate(f"({px},{py})", (px, py), textcoords="offset points",
                 xytext=(0, 6), fontsize=7, rotation=90,
                 ha='center', va='bottom')

plt.margins(0.15)
plt.axis("equal")
plt.grid()
plt.legend()
plt.show()
