import matplotlib.pyplot as plt

xmin, ymin = map(float, input("Window min x y: ").split())
xmax, ymax = map(float, input("Window max x y: ").split())
x1, y1 = map(float, input("Start x y: ").split())
x2, y2 = map(float, input("End x y: ").split())

ox, oy = [x1, x2], [y1, y2]

def code(x, y):
    c = 0
    if x < xmin: c |= 1
    if x > xmax: c |= 2
    if y < ymin: c |= 4
    if y > ymax: c |= 8
    return c

def line_points(x1, y1, x2, y2):
    """Every point on the line, so the plotted line shows its pixels."""
    n = int(max(abs(x2 - x1), abs(y2 - y1)))
    if n == 0:
        return [(x1, y1)]
    return [(x1 + (x2 - x1) * i / n, y1 + (y2 - y1) * i / n)
            for i in range(n + 1)]

while True:
    c1, c2 = code(x1, y1), code(x2, y2)

    if not (c1 | c2):
        accept = True
        break
    if c1 & c2:
        accept = False
        break

    c = c1 or c2

    if c & 8:
        x = x1 + (x2-x1)*(ymax-y1)/(y2-y1)
        y = ymax
    elif c & 4:
        x = x1 + (x2-x1)*(ymin-y1)/(y2-y1)
        y = ymin
    elif c & 2:
        y = y1 + (y2-y1)*(xmax-x1)/(x2-x1)
        x = xmax
    else:
        y = y1 + (y2-y1)*(xmin-x1)/(x2-x1)
        x = xmin

    if c == c1:
        x1, y1 = x, y
    else:
        x2, y2 = x, y

original_pts = line_points(ox[0], oy[0], ox[1], oy[1])

print("Original line points:")
for p in original_pts:
    print(p)

plt.figure(figsize=(12, 6))
plt.plot([xmin,xmax,xmax,xmin,xmin],
         [ymin,ymin,ymax,ymax,ymin], 'k-', label="Window")

plt.plot([p[0] for p in original_pts], [p[1] for p in original_pts],
         'b--', marker='o', markersize=4, label="Original")

labels = {}
if accept:
    clipped_pts = line_points(x1, y1, x2, y2)

    print("Clipped line points:")
    for p in clipped_pts:
        print(p)

    plt.plot([p[0] for p in clipped_pts], [p[1] for p in clipped_pts],
             'r-', linewidth=3, marker='o', markersize=5, label="Clipped")

    for p in clipped_pts:
        labels[p] = 'red'
else:
    print("Line rejected")

for p in original_pts:
    labels.setdefault(p, 'black')

for (px, py), c in labels.items():
    plt.annotate(f"({px:g},{py:g})", (px, py), textcoords="offset points",
                 xytext=(0, 6), fontsize=6, color=c, rotation=90,
                 ha='center', va='bottom')

plt.margins(0.15)
plt.axis('equal')
plt.grid()
plt.legend()
plt.show()
